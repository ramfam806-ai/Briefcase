# Google Sheets Budget Planner

Take control of your finances with this powerful yet simple budget tracker.

## Quick Start
1. Open Google Sheets
2. Go to File → Import → Upload
3. Follow the tabs to track income, expenses, and savings

## Features
- Income & expense tracking with categories
- Monthly dashboard with visual summaries
- Annual overview
- Savings goal tracking
- Automatic calculations
