# PDF Weekly Planner

A clean, minimalist weekly planner PDF designed for focused professionals.

## What's Included
- 12 unique weekly layouts (one per month)
- Bonus: Monthly review page
- A4 and US Letter sizes
- Print or use digitally with annotation apps

## How to Use
1. Open the PDF
2. Print or use in GoodNotes/Notability
3. Start planning!
